package Online_Art_Galleryy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineArtGallery1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
